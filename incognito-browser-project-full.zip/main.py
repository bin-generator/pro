
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
import webbrowser

class Browser(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.search_input = TextInput(hint_text='Search or enter address', multiline=False)
        self.search_input.bind(on_text_validate=self.on_enter)
        self.add_widget(Label(text='Incognito Browser', size_hint=(1, 0.1)))
        self.add_widget(self.search_input)
        self.add_widget(Button(text='Search', on_press=self.search))

    def search(self, instance):
        query = self.search_input.text.strip()
        if query:
            webbrowser.open("https://www.google.com/search?q=" + query)

    def on_enter(self, instance):
        self.search(None)

class IncognitoApp(App):
    def build(self):
        return Browser()

if __name__ == '__main__':
    IncognitoApp().run()
